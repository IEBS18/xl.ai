"use client"

import { useState } from "react"
import { ThemeProvider } from "./components/theme-provider"
import { SpreadsheetProvider } from "./lib/spreadsheet-context"
import { LandingPage } from "./components/landing-page"
import { SheetsInterface } from "./components/sheets-interface"
import "./index.css"

export default function App() {
  const [showApp, setShowApp] = useState(false)

  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
      <SpreadsheetProvider>
        {!showApp ? <LandingPage onGetStarted={() => setShowApp(true)} /> : <SheetsInterface />}
      </SpreadsheetProvider>
    </ThemeProvider>
  )
}
