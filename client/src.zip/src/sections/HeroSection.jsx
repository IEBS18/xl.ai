import React, { useState, useRef } from "react"
import { Send, Paperclip } from "lucide-react"
import { motion } from "framer-motion"
import { useTheme } from "../context/ThemeProvider"
import { getTimeBasedGreeting } from "../utils/helpers"
import ThreeBackground from "../components/ThreeBackground"
import AnimatedInterface from "../components/AnimatedInterface"

const HeroSection = ({ isConnected, onSendMessage, onFileUpload }) => {
  const { themeClasses } = useTheme()
  const [inputMessage, setInputMessage] = useState("")
  const heroRef = useRef(null)

  const handleSendMessage = () => {
    if (!inputMessage.trim() || !isConnected) return
    onSendMessage(inputMessage)
    setInputMessage("")
  }

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <section className="relative pt-32 pb-20 overflow-hidden">
      {/* Three.js Background */}
      <ThreeBackground ref={heroRef} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="relative h-full w-full overflow-hidden">
          {/* Background with enhanced visibility */}
          <div className="absolute inset-0 z-0">
            <div className="absolute inset-0 bg-gradient-to-br from-gray-900/80 via-gray-950/85 to-black/90 z-20"></div>

            {/* Animated Interface Screenshots */}
            <AnimatedInterface />

            {/* Enhanced ambient background elements */}
            <div
              className="absolute top-1/4 left-1/4 w-64 h-64 bg-gradient-to-r from-blue-500/8 to-indigo-500/8 rounded-full blur-3xl animate-bounce"
              style={{ animationDuration: "8s" }}
            ></div>
            <div
              className="absolute bottom-1/4 right-1/4 w-56 h-56 bg-gradient-to-r from-purple-500/8 to-pink-500/8 rounded-full blur-3xl animate-pulse"
              style={{ animationDuration: "10s" }}
            ></div>
            <div
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-gradient-to-r from-indigo-500/6 to-blue-500/6 rounded-full blur-3xl animate-ping"
              style={{ animationDuration: "12s" }}
            ></div>
          </div>

          {/* Content */}
          <div className="relative z-20 flex flex-col items-center justify-center h-full text-center max-w-4xl mx-auto px-6">
            {/* Stylish Greeting */}
            <div className="mb-8 animate-fadeIn">
              <div className="mb-4">
                <h1
                  className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-100 to-indigo-200 mb-3 tracking-tight leading-none"
                  style={{ fontFamily: "SF Pro Display, -apple-system, BlinkMacSystemFont, system-ui, sans-serif" }}
                >
                  {getTimeBasedGreeting()}, Ayush
                </h1>
                <div className="h-0.5 w-24 bg-gradient-to-r from-blue-400 via-purple-500 to-indigo-500 mx-auto rounded-full shadow-lg"></div>
              </div>
              <p
                className="text-lg text-gray-200 mb-2 font-light tracking-wide"
                style={{ fontFamily: "SF Pro Text, -apple-system, BlinkMacSystemFont, system-ui, sans-serif" }}
              >
                Welcome back to DataScope AI
              </p>
              <p
                className="text-sm text-gray-400 font-light tracking-wide"
                style={{ fontFamily: "SF Pro Text, -apple-system, BlinkMacSystemFont, system-ui, sans-serif" }}
              >
                Ready to unlock insights from your data?
              </p>
            </div>

            {/* Enhanced Central Input Area */}
            <div className="w-full max-w-2xl mb-10 animate-slideIn" style={{ animationDelay: "0.3s" }}>
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-indigo-500/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
                <div className="relative">
                  <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder={
                      !isConnected
                        ? "Connecting to server..."
                        : "Upload a file or describe what you'd like to analyze..."
                    }
                    disabled={!isConnected}
                    className="w-full px-6 py-4 bg-gray-800/90 backdrop-blur-xl border border-gray-600/60 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/60 focus:border-blue-500/60 disabled:bg-gray-900/80 disabled:text-gray-500 text-base shadow-2xl text-white placeholder-gray-400 transition-all duration-300 font-light"
                    style={{ fontFamily: "SF Pro Text, -apple-system, BlinkMacSystemFont, system-ui, sans-serif" }}
                  />
                  <div className="absolute right-4 top-1/2 transform -translate-y-1/2 flex items-center space-x-3">
                    <button
                      onClick={onFileUpload}
                      className="p-2 text-gray-400 hover:text-white hover:bg-gray-700/60 transition-all duration-200 rounded-xl backdrop-blur-sm group-hover:scale-105"
                      title="Upload file"
                    >
                      <Paperclip size={18} />
                    </button>
                    <button
                      onClick={handleSendMessage}
                      disabled={!inputMessage.trim() || !isConnected}
                      className="bg-gradient-to-r from-blue-500 to-purple-500 text-white p-2 rounded-xl hover:from-blue-600 hover:to-purple-600 transition-all duration-200 disabled:from-gray-600 disabled:to-gray-700 disabled:cursor-not-allowed shadow-xl transform hover:scale-105 disabled:transform-none backdrop-blur-sm"
                    >
                      <Send size={18} />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Refined Feature Info */}
            <div className="text-center animate-slideIn" style={{ animationDelay: "0.6s" }}>
              <div className="text-gray-400 space-y-4">
                <p
                  className="font-medium text-base text-gray-300"
                  style={{ fontFamily: "SF Pro Text, -apple-system, BlinkMacSystemFont, system-ui, sans-serif" }}
                >
                  Supports CSV, Excel files up to 50MB
                </p>
                <div className="flex items-center justify-center space-x-8 text-sm">
                  <span className="flex items-center space-x-2 group cursor-default">
                    <div className="w-2 h-2 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full shadow-lg group-hover:shadow-green-400/50 transition-all duration-300"></div>
                    <span
                      className="font-medium text-gray-300"
                      style={{
                        fontFamily: "SF Pro Text, -apple-system, BlinkMacSystemFont, system-ui, sans-serif",
                      }}
                    >
                      Real-time Analysis
                    </span>
                  </span>
                  <span className="flex items-center space-x-2 group cursor-default">
                    <div className="w-2 h-2 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-full shadow-lg group-hover:shadow-blue-400/50 transition-all duration-300"></div>
                    <span
                      className="font-medium text-gray-300"
                      style={{
                        fontFamily: "SF Pro Text, -apple-system, BlinkMacSystemFont, system-ui, sans-serif",
                      }}
                    >
                      Interactive Charts
                    </span>
                  </span>
                  <span className="flex items-center space-x-2 group cursor-default">
                    <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-indigo-500 rounded-full shadow-lg group-hover:shadow-purple-400/50 transition-all duration-300"></div>
                    <span
                      className="font-medium text-gray-300"
                      style={{
                        fontFamily: "SF Pro Text, -apple-system, BlinkMacSystemFont, system-ui, sans-serif",
                      }}
                    >
                      Strategic Reports
                    </span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default HeroSection